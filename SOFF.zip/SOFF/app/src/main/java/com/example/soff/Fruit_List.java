package com.example.soff;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.widget.ArrayAdapter;
import android.widget.ListView;

import java.io.BufferedReader;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;

public class Fruit_List extends AppCompatActivity {
    ListView list;
    String[] strings;
    List<String> fruit_list = new ArrayList<String>();
    ArrayAdapter<String> arrayAdapter;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_fruit__list);
        arrayAdapter = new ArrayAdapter<String>(this,android.R.layout.simple_list_item_1,fruit_list);
        list = (ListView)findViewById(R.id.list);
        list.setAdapter(arrayAdapter);
        read_text_file();
    }
    public void read_text_file()
    {
        InputStream inputstream= null;
        try {
            inputstream = getApplicationContext().openFileInput("fruits.txt");

        if(inputstream != null){
            InputStreamReader inputstreamreader = new InputStreamReader(inputstream);
            BufferedReader bufferedReader = new BufferedReader(inputstreamreader);
            String receivestring = "";
            //StringBuilder stringBuilder = new StringBuilder();

            while( (receivestring = bufferedReader.readLine()) != null){
                fruit_list.add(receivestring);
                arrayAdapter.notifyDataSetChanged();
            }
                inputstream.close();
        }
        } catch (FileNotFoundException e) {
            e.printStackTrace();
        }
        catch(IOException e){
            e.printStackTrace();
        }
    }
}
