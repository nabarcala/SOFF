package com.example.soff;

import androidx.appcompat.app.AppCompatActivity;

import android.bluetooth.BluetoothAdapter;
import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;
import android.content.IntentFilter;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.Button;

public class Connectivity_Activity extends AppCompatActivity {
    private static final String TAG = "Connectivity_Activity";
    BluetoothAdapter mBluetoothAdapter;
    Button btnEnableDisable_Discoverable;

    //Create a BroadcastReceiver for ACTION_FOUND
    private final BroadcastReceiver mBroadCastReceiver1 = new BroadcastReceiver() {
        @Override
        public void onReceive(Context context, Intent intent) {
            String action = intent.getAction();
            //catch action state change request
            if(action.equals(mBluetoothAdapter.ACTION_STATE_CHANGED))
            {
                final int state = intent.getIntExtra(BluetoothAdapter.EXTRA_STATE,mBluetoothAdapter.ERROR);
                switch(state){
                    case BluetoothAdapter.STATE_OFF:
                        Log.d(TAG,"onReceive: STATE OFF");
                        break;
                    case BluetoothAdapter.STATE_TURNING_OFF:
                        Log.d(TAG,"onReceive: STATE TURNING OFF");
                        break;
                    case BluetoothAdapter.STATE_ON:
                        Log.d(TAG,"onReceive: STATE ON");
                        break;
                    case BluetoothAdapter.STATE_TURNING_ON:
                        Log.d(TAG,"onReceive: STATE TURNING ON");
                        break;

                }
            }
        }

    };
    //Broadcast receiver for changes made to bluetooth states such as Discoverability mode on/off
    private final BroadcastReceiver mBroadcastReceiver2 = new BroadcastReceiver() {
        @Override
        public void onReceive(Context context, Intent intent) {
            final String action = intent.getAction();
            if (action.equals(BluetoothAdapter.ACTION_SCAN_MODE_CHANGED)){
                int mode =  intent.getIntExtra(BluetoothAdapter.EXTRA_SCAN_MODE, BluetoothAdapter.ERROR);
                switch(mode){
                    //device is in descoverable mode
                    case BluetoothAdapter.SCAN_MODE_CONNECTABLE_DISCOVERABLE:
                        Log.d(TAG, "mBroadCastReceiver2: Discoverability enabled");
                        break;
                    //device is not in discoverable mode
                    case BluetoothAdapter.SCAN_MODE_CONNECTABLE:
                        Log.d(TAG, "mBroadCastReceiver2: Discoverability disabled. Able to receive connections");
                        break;
                    case BluetoothAdapter.SCAN_MODE_NONE:
                        Log.d(TAG, "mBroadCastReceiver2: Discoverability disabled. Not able to receive connections");
                        break;
                    case BluetoothAdapter.STATE_CONNECTING:
                        Log.d(TAG, "mBroadCastReceiver2: Connecting");
                        break;
                    case BluetoothAdapter.STATE_CONNECTED:
                        Log.d(TAG, "mBroadCastReceiver2: Connected");
                        break;
                }
            }
        }
    };



    @Override
    protected void onDestroy(){
        Log.d(TAG,"onDestroy: called");
        //fixes a crash when a receiver that is unregistered is registered
        //may cause problems later, idk
        try {
            unregisterReceiver(mBroadCastReceiver1);
            unregisterReceiver(mBroadcastReceiver2);

            //Register or UnRegister your broadcast receiver here

        } catch(IllegalArgumentException e) {

            e.printStackTrace();
        }
        super.onDestroy();
    }


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_connectivity);
        Button btnONOFF = (Button) findViewById(R.id.btnOFFON);
        btnEnableDisable_Discoverable = (Button) findViewById(R.id.btnDiscoverable_on_off);


        mBluetoothAdapter = BluetoothAdapter.getDefaultAdapter();
        btnONOFF.setOnClickListener(new View.OnClickListener(){
            @Override
            public void onClick(View view){
                Log.d(TAG,"onClick: enabling/disabling bluetooth");
                enableDisableBT();
            }


        });

    }
    public void enableDisableBT()
    {
        if (mBluetoothAdapter == null)
        {
            Log.d(TAG,"device not capable of using bluetooth");
        }
        if(!mBluetoothAdapter.isEnabled())
        {
            Log.d(TAG,"onClick: enabling bluetooth");
            Intent enableBTIntent = new Intent(BluetoothAdapter.ACTION_REQUEST_ENABLE);
            startActivity(enableBTIntent);

            //catches state changes of BT and logs it
            IntentFilter BTIntent = new IntentFilter(BluetoothAdapter.ACTION_STATE_CHANGED);
            registerReceiver(mBroadCastReceiver1, BTIntent);
        }
        if(mBluetoothAdapter.isEnabled())
        {
            Log.d(TAG,"onClick: disabling bluetooth");
            mBluetoothAdapter.disable();
            //catches state changes of BT and logs it
            IntentFilter BTIntent = new IntentFilter(BluetoothAdapter.ACTION_STATE_CHANGED);
            registerReceiver(mBroadCastReceiver1, BTIntent);
        }
    }
    public void btnEnableDisable_Discoverable(View view)
    {
        Log.d("TAG","Making device discoverable for 300 seconds");
        Intent discoverableIntent = new Intent(BluetoothAdapter.ACTION_REQUEST_DISCOVERABLE);
        discoverableIntent.putExtra(BluetoothAdapter.EXTRA_DISCOVERABLE_DURATION,300);
        startActivity(discoverableIntent);

        IntentFilter intentfilter = new IntentFilter(mBluetoothAdapter.ACTION_SCAN_MODE_CHANGED);
        registerReceiver(mBroadcastReceiver2,intentfilter);
    }

}
