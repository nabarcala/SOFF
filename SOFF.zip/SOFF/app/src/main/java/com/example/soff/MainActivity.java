package com.example.soff;

import androidx.appcompat.app.AppCompatActivity;
import androidx.localbroadcastmanager.content.LocalBroadcastManager;

import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;
import android.content.IntentFilter;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.os.Bundle;
import android.util.Base64;
import android.util.Log;
import android.view.View;
import android.widget.ArrayAdapter;
import android.widget.ImageView;
import android.widget.Spinner;
import android.widget.Toast;

import java.nio.charset.Charset;

public class MainActivity extends AppCompatActivity {
    ImageView image;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        //code for the dropdown menu for cuts
        Spinner cutSpinner = (Spinner) findViewById(R.id.cuts_spinner);
        ArrayAdapter<String> myAdapter = new ArrayAdapter<String>(MainActivity.this,
                android.R.layout.simple_list_item_1, getResources().getStringArray(R.array.cuts));
        myAdapter.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);
        cutSpinner.setAdapter(myAdapter);
        image = (ImageView)findViewById(R.id.picture_imageView);
        LocalBroadcastManager.getInstance(this).registerReceiver(mReceiver, new IntentFilter("incomingImage"));

    }

    //add code here for slicing fruit
    public void sliceFruit(View view) {
        try {
            String command = "cut1";
            byte[] bytes = command.toString().getBytes(Charset.defaultCharset());
            ((Startup) this.getApplicationContext()).b.write(bytes);

            Context context = getApplicationContext();
            //CharSequence text = ((Startup)this.getApplicationContext()).b.getGetDeviceName();
            CharSequence text = command;
            int duration = Toast.LENGTH_SHORT;

            Toast toast = Toast.makeText(context, text, duration);
            toast.show();
        }
        catch(NullPointerException e)
        {
            Context context = getApplicationContext();
            //CharSequence text = ((Startup)this.getApplicationContext()).b.getGetDeviceName();
            CharSequence text = "Error";
            int duration = Toast.LENGTH_SHORT;

            Toast toast = Toast.makeText(context, text, duration);
            toast.show();
        }
    }

    //code for when user clicks on settings button
    public void settings(View view) {
        // Create an Intent to start the settings activity
        Intent settings = new Intent(this, Settings_Activity.class);
        //Start the settings activity
        startActivity(settings);

    }

    public void TestConnection(View view) {
        // Create an Intent to start the settings activity
        //Intent connectivity = new Intent(this,Connectivity_Activity.class);
        //Start the settings activity
        //startActivity(connectivity);
        this.finish();

    }
    public void cancel(View view)
    {
        String text = "/9j/4AAQSkZJRgABAQAAAQABAAD/2wCEAAkGBxITEhUTExMWFRUXGBUWFxYYFhYXFxcXGBUYFhgYGBcYHSggGBolHRcVITEhJSkrLi4uFx8zODMtNygtLisBCgoKDg0OGxAQGy0lHyUtLTItKy8tLS0tLi0tLy8tLS8tLS0tLS0tLS0tLy0tLS0tLS0tLS0tNS0tLS0tLS0tLf/AABEIAOEA4QMBIgACEQEDEQH/xAAbAAABBQEBAAAAAAAAAAAAAAAAAQIDBAUGB//EADYQAAEDAgQEBAUEAgIDAQAAAAEAAhEDIQQxQVEFEmFxgZGh8CIyscHRBhPh8SNCFHJSYtIV/8QAGgEAAQUBAAAAAAAAAAAAAAAAAAECAwQFBv/EAC0RAAICAQQABAQGAwAAAAAAAAABAgMRBBIhMQUiQVFCYZHxFFJxocHwE4Gx/9oADAMBAAIRAxEAPwD3FCEIAEIQgAQhCABCEIAEIQgAQhCABCQlM/ebuPNJlBgkQojiWf8AkPNAxDD/ALDzSbl7i7X7EqE0PG4Tk4QEIQgAQhCABCEIAEIQgAQhCABCEIAEIQgAQhCABCEIAEITXvAzQA5Nc8DMqhi8faGmD70WRiMSTPXN32GpVO7WRr65LFenlLs2K/FGiwufRZtbjTjPLprkPrdZTmyI8h37fdQloDIJkzk28+MQsW/xK59cI0K9JWvmWa3E6ptzNJ6SD9Uf81xJgSNh8QJ2iSFlgwZIAjSVG6teAsx6631bLy00fRGq/FuBuHA6QG2H2TH8RF/ieDaxt6hZZq+yk/c2y2SfjbPf+/sOWnj6mp/+nmBrrJPluruH464ZOnLMR9ZXPuYb2y0UbX/j0kKSGt1EHlMHpa5Lo7nD8eafmBHXTuOi06GJa8S0yvPqVWGOMHMQNNjfdWMFjiDPqJ9VrU+LtYVnqZ9vhyeXA79CwMFxox8fxDeL+llt0KzXCQZW1VfC1eVmZZTOvskQhCmIgQhCABCEIAEIQgAQhCABCEIAEIVbE4kNtqmykorLFSbeEOr4gNWTicUSc/fRMr1SSdYj+dFWczIkx+fe6y79S5cIvVUpcsa9xc6LxrbMhVnvPy2GkZKw6kbkG7TcTc9x4phZLoM3kzEx0nz1WZYpSLccIp1nQIiYByt/SryJEZGJkAxv3Vzm5XOHNeIAiSb6eSril8YYRIOsAEWy9Qs6yDbWPsWoPgp1WiTBn3soYvb+U/EkAkD0Uf7ceN46KnguR6IjTJyN0gqQ2e7XD6HoQpw06KzTw7SLwAbEWlTU8vAs5pdiYEc4ufijl3nULNxNf/I4ZRFvCyc1xoVIOQMcwyic/D7KlxiualXmY3RoJEQ4xm3fbyV1Vude31TInZGuW6T4aNbEVSGOA1dBE6gAz6n0UWFqTIO3nFwFFWwNZjeepytBjmEl3LIJE2g6CRqocNUvGkjqor65RktyH0yhZDMWdJgINOSYiTuBbXWVdwONiC0m/gFz9WuWAsBBD4JIzzMdlocLM/CXEdLADvurVFzjKMY94/cq3U+VyfX8Ha4LFh46jMK0uWa51MzMHfQwugwOKFRsjPULpNPqN/ll2YV9OzzR6LKEIVorghCEACEIQAIQhAAhCZUfAlI3jkCLFV+UWzWTXqzv13hPrVC5w96KEMO8b9ll33Ob46LtcFFciRt21J9/wla0tEnli82g+WtlNToC8Hr1yTGkDnNoBuesGZUWzHLJN2eitiWwJaBJIAmYkwNO6TEfA4E2Dbm0h2evdD3Q0vkHmcOSR6DfVFao05uECbG0kC5O8H6KCWOccdEyKFegSWukAmO8ETHRQ1nh3MT8IHywTJNspysn06k1eYRAB+IzygQbNG8R5LNrPdoQZPYd8lkXyWOPVv7l6uDbEAkF1heFEXXylLiRFgbT80KBzhpluqLiXIol/eVykLAhYhrXWsys0cpnfI3BB1U1daTyxti9g/UWBcKBfTP+QCQMgdS2b2P4XDY3ipcWuLSJHxMDp+ZojlNri4nvZd5iK7qjeU2G4zv19Fk4v9N0X04czQ8rtQe4iRfI+i06dbVGW1dGdfpZTSfqYv6f4zi8Q2pQqN5mOA5TDvhIuPiFvmDPorWF58ogix3BGaoYLguMw1UEOpvYYhwlpBGU3n1grdo4eoTzOILjckWk6WTtbbXNJxaJdBCyptSXDF/cJ+bPeFp8FqNDwHOIG/ha/dUwHCxEqfDsaTmBG8D2VnVTe9NI0bcODRv4XFmo3lj5ZD72MyJIH1Vvh9U03SJjIj3bqCs3BPnlc0/LIIi5adDGtpWjVEm2UCBpfT6ELbpm8KWeTGtik3HHB09N4cARkbpVlcDxFiza4+497rWW7VPfFSMeyGyTQIQhSDAQhCABCEIAFmcQxN40V3E1Iad8gsRzpcTpn5aeipau3C2osUQy8sfTZYkm2fgrNIWkajL6X8lHSB28N/5Upm8evTWPeSrQjjkkk8jWEybRYeJMqrXrtAfOTRJ6k9s9FYq5g3+EmOpjXosfiNRzopgiXZgA5c0A9oPjHVR32OESamG5kOFmrUAkgNNhHytFtcibeYUvEKjGuIEAn4Z+aACP5U9mEU2f+xc8nrN+ufsLII56hgAgAjmOUZT/ANtclmXScIbVzJsuQSnLd0kiviKwJhpMZkny9/ZR1acFtwBNxmY8PopKrmteA0SWznkSNeoCqVqkGcz91mS757NCC6wNxBJdnb6eCpV699OimxVWJFpUWGwpeQflZME+pjdLCOeyZcLLFw9E1Msm3n6/ZXBytspK1ZjAQ0Q0x5Cf7VJ74N7Js+XhDVmReZVF/vupqlaQOYi2Qyz16rJNdWf+SHC+YEA7CZ+5SJYTGuHOTSwoDmuB08baqniKf7bi3Yp2FrjPIRB8bLR/4batMgGHDI9oU9dX+SO1dkbl/jll9Ge6CB9VM/BhrC50yCMrS0xBjUZ+SzWV3MJad4PcH8hdH/yv8X7g+KOUub0uD4aqXT1xlnd2kFznDGOmLw1xLREWsP8A5O2t+i0KlIzOgNu2oPgSqsBxlosWzItOdp3GYVqgJIIdIItnMjPzWvWsLBmWvLyOZ/jeCLRp6R9l0bXSJC56Rnp9vdlrcLqTTA2t+Fo6SWG4lHULKTLiEIV4qAhCEACEIQBm8Vq6e7/0Vm099PrcAD0Kk4jUlx7/AE/tFKAfp4DPzKxbZ77WaEI7YIsNmNNP5RXqw1xtYSLxodUnOL2/tQ1TaJve+s9E9ywuBqjlkdV8fCbmpczk1sRl6xuVRpmDUfrzGm0m5cTa09UnEa/+NoDi4xd19tB4a9FBiXu5aRgyRzRoL5nrl5LPttWf0/n7l2uvj9SOm8ctWTzOuBoAAZJt1jzVN7wGNaDfNx0k6eQCTE1YDmsvzES7Vx/EqIxIkWAy3IG/dZFlmeF+mf8AeTQhD1f94GPrG8a59VRxNSNVPWeADuTKr0MN+4STYAfxATIL3LUUksiYbBOq/Fk0arRxdRghrflaPM/hPxlZoimyzBE9epWbWcSRspJS+FdDVmbyxH1hHZRVKk+N5KbUdboq9Soe6IxJMEtRsxBuCZG49yloPg3ggzbwVYPUlNtxdSYDBpYV1yNCP5+y2eEYjmHIZBBPllcd1zlImJ1H5WphcSWumJJAd3vH2RXLZLJFdXuiVeKgis+1jH0GSv8AAsSWgkXgTHTW2tpVfGUmF4IMATEnKZIB7G3ZQ8Ne5sEEXsROhspIvFm75hJKVW35HTcPxLYnIGGx0/1B8yJ7K42i1sESGj7j2PDosenUECfhcC1pzgxlI0OYVvCYkG7X55g6RYx6R1WjXYuEzMtreW0ajanSJ9n1V7hL/icNwD781imsZIB2IJ+oPfRXuG1fjaZmbefv0Vyizzop21+RnQoQhbBmAhCEACbUMAnonKHGOhjo2P0TZPCbFSyzncUQXmd/up6Jt1Veu2Xnv9/6Uodb373WBF+Zs1GvKkTPqDeBp795Kq75i4xYHlk9L5ZCySrU1izbx1jRVeYhvMTLjaBcRNvrKLLB0KyB9Q/tAm2fK0WJAkSSb5FZ9R0MBLpcRBGw/wBRdTltqjjcwOUZwLXPWIVeqJPIBkC49wLzssi5uX0/v/PoaVcUhrgIaBnEk9zaPCFVqVABqbyU+tV1zOU+EKCnSLvv/SqPBajHCyxlKmXOvln4BW61QNbytHWd0793laItIIMZxOseCrF5IQ2LzJ5fRHVd5lVKtQ6qasTPdVnDNSwRKgr9VAnmpuoSdVLFBge11o9U5rfFQjopW7+CcwJqdS0afhX6DgQbwQLd1nF22uasAixGQAkdVGxGi5iyP25Lc7SP9TH3+yrYNt2g5nLKCnOdlJtoevUJtGYE6ER00sUuc9iJYRpUwCA5ztZg5gtNgR1Gyttew3HwEzMXbI1i3uVlAHODb+lPSbqM9R6GPQqWNmOMEE6/mbLXAQQ4nUaRuOyuYCp8bcsxllmFkYSpsNovuII8wFfwrviaQAMt/eyv0T5TKNsOGjt0IQumOdBCEIAFHiGy0jopE2oLHskkspoVdnM1Ww6esR2kj0CYaoymPealxVj4fwqbyPHbr7lc7Z5WbEFlC1ncxibEHWO6qYy4LQYhonoFK50CS24b5SqzuUNmPieIJz3k59lVtllMs1xxgixxAcIyIaAI67aKpVfDnQdx56J7qg5wYysZ7RKruEgG8SR4jT1CzrZbnlF2uOFhkVNkxGV1O74SQm0rRtn+LKKoJvsoSXtjSUjTY9U2s+YO5SE5hOwPI6wt1VUkQdSrjj5RZU6ggqWA9EJF0w3UhTICmQCtUg1Kj8E5vmhgOFvFWKcdbyFAxSN1PaPNMY0n/bNwDIEW65flLhnzpN79Pf2TWZZ6yfRJgrEjt+UIC22Y8fTopQds7qKkbDxspGgIGMu0qkxJM5me48tVp4IfEB1CyKNz6ei2eFsl7P8AsPx9IWhpeZIpajiLO2QhC6o5cEIQgASFKhAHM8RsexhZNR2d9dlu8apXPW48oXP4jKO31XN6yLjNm5pWpRQ0kmZNovfyChqO5oyDRHpoN0VX3+igqmBlrPWSsyci/GIyq6TbInz7+aa8z26ZeHkld/4jefH2FHblAvmSq0idITmgePpsmvtYJSZlRVHCx7eaZgkSGPN4TNR7lSPbPQqInfz6p6HDa1zqonz3UtUXzUXKpIikBHmk5lI4ayIRynTT3mpAGTOcBOHRHJunFgSCCBiewzZRgZBPbAhDAlbEGbe5SYTUG0iEtQ293TKFj5wk9BC5llOgiPWylYTO2Sr8wUtP6n0397oXYPovUBPTL8fRdH+n6fNUHQk+Q/K5zBffztl9fJdj+mKVi7w87n6DzWx4dDM0ZWvltrZvIQhdEc6CEIQAIQhAGbxqlLZ2t5rlMU3fQ/b35LuqzOZpG647iNEgkEX/AAsjxKr4kamgs+EynGPVQDOTv6KWoLqJ+vj5Lnpo24kUwD1v4JjReE90ndRtOeu2agZMhrnHPrdMcQSlcZHZMfb+NkmB6QjjrF/VK4BMBvM2v/SV82jxS4AheM0lk/mOsSm81zsnoGRxI6JCyyeQLIjonCZGxG6bKcZ1SOCUBC7yyTmhNHRPAQxMi1D8P2RT9UyoQnApBCVpt3Vinp4/lVmfcq1RGXqnRWWK3waeAbJ97H8rv+F0OSm0axJ8VyP6cwf7jxP/AGPbbzsu5XS+G1bYbmc74nbmWxAhCFpmWCEIQAIQhAAsXjuE/wBx499FtJlWmHAg5GyjtrVkHFklVjhJSPP69OFSePwug4pgixxGmh3ErEqsuuW1NLi8M6WixTWUVHfX+VCT4qchQP8A5WfJF2I0m6Zr9t0pKaR72SYJBs36X7pC/wAkO9U0JRAdvsh46+9kEQc80hMJRBuSRuiI/pHdOGh5ppKe5yYQhAKAlBTCUpKBAcbpWpie1LgQma3VaFBl+/1zVSi1dh+leFcx/dcPhHyg6nfsPr2V/Sad2SSRX1N6qg5M3+B4L9qmJ+Y3PTYe91pJoShdRCKjFRRys5ucnJ+oqEIThoIQhAAhCEACEIQBBjMKKjYPgdiuM4lgXU3EELulVx+CbVbDvA7KpqtMro8dlvS6l0y56POKjPexVaq0+K3OJ4BzHEERsd+yyKjPDsuZuocXhnS02qSyioc/eaaVK9qjVVxLSIzumkbJ5G3omOHkgXAOKbKUpjihDcDgkJ6ppckJSiMHFI4pEhclwIKkJSSkBTkhrJB/SmptVelffuum/T/AXVYe/wCGn6v7dOvsW6NPKbwkV7ro1x3SZL+nODmq6XCGDM7/APqOv08l31JoAAAgCwAyAUGGpBrQ1oAAsANFZauk09Eao4XZzep1ErpZfXoh4ShIE5WCsCEIQAIQhAAhCEACEJCgAJTSUpTCkYEGMw7ajeV4keoO4XKcV4I5t2/E318Quueq9RVb9PC1c9+5b0+onS+OvY87q0oVWo1dvxDhzHyYg7j7jVc3juGPblDvQ+RWJfoJx65Og0+urn28P5mOQo3OUlcEG4I72Vdz1nSg08M0YtNZFc5M5lE6oon1kigI2T8yaXyq5rJjqyeoDGy0HpC9Vf30+lzOs0E+90+NUm8JEcpxistk4cpcPTc93K1pcdAM1e4bwQuvUdbZv5/hddwzBMYIY0NHqe5zK0aPD5PmXBnX+IQjxDllPgn6bDSH1bnRn+o7nXtl3XXUgq+HpK/TpraqqjWsRRiXXSteZMcxqmASNangKcrgEqEIAEIQgAQhCABCEIAEhSoQA1IQnEJCEAROChexWSE0tTWhyZnVqaoYjDSt11NQuw6Y4D1PByeK4fOixMXwSdF6E/CKB/Dxso3Un2iVXtdM8vr8DdpKpVOD1BqV6s/hY2UD+DjZM/DV/lX0H/i7PzP6nlJ4XU3Ss4Q/WV6ieCDZObwQbIWnrXwr6CPVWP4n9TzrDcGOy3MBwo7LsKfBwNFco8OA0UqrS6IpWt9mJguHwtrDYWFdp4YBTtpqRRI3Iip0lOGpQE5PGCAJUIQAIQhAAhCEACEIQAIQhAAhCEACQoQgBEIQgBEhQhAAkKEJAEKYUIQKIhCEgDgnhCEog5OQhKAqEIQAIQhAAhCEACEIQAIQhAH/2Q==";
        Bitmap bm = ConvertStringToImage(text);
        image.setImageBitmap(bm);
    }
    BroadcastReceiver mReceiver = new BroadcastReceiver() {
        @Override
        public void onReceive(Context context, Intent intent) {
            String text = intent.getStringExtra("theImage");
            //messages.append(text + "\n");
            //Log.d(TAG,"Displaying message");
            //incomingMessages.setText(messages);
            Bitmap bm = ConvertStringToImage(text);
            image.setImageBitmap(bm);

        }
    };
    //converts a string to a bitmap image
    public Bitmap ConvertStringToImage(String encodedString)
    {
        try {
            byte[] encodeByte = Base64.decode(encodedString, Base64.DEFAULT);
            Bitmap bitmap = BitmapFactory.decodeByteArray(encodeByte, 0, encodeByte.length);
            return bitmap;
        } catch (Exception e) {
            e.getMessage();
            return null;
        }
    }
    public void scan(View view)
    {
        try {
            String command = "Scan";
            byte[] bytes = command.toString().getBytes(Charset.defaultCharset());
            ((Startup) this.getApplicationContext()).b.write(bytes);

            Context context = getApplicationContext();
            //CharSequence text = ((Startup)this.getApplicationContext()).b.getGetDeviceName();
            CharSequence text = command;
            int duration = Toast.LENGTH_SHORT;

            Toast toast = Toast.makeText(context, text, duration);
            toast.show();
        }
        catch(NullPointerException e)
        {
            Context context = getApplicationContext();
            //CharSequence text = ((Startup)this.getApplicationContext()).b.getGetDeviceName();
            CharSequence text = "Error";
            int duration = Toast.LENGTH_SHORT;

            Toast toast = Toast.makeText(context, text, duration);
            toast.show();
        }
    }

}
