package com.example.soff;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.ArrayAdapter;
import android.widget.Spinner;

public class MainActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        //code for the dropdown menu for cuts
        Spinner cutSpinner = (Spinner) findViewById(R.id.cuts_spinner);
        ArrayAdapter<String> myAdapter = new ArrayAdapter<String>(MainActivity.this,
                android.R.layout.simple_list_item_1,getResources().getStringArray(R.array.cuts));
        myAdapter.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);
        cutSpinner.setAdapter(myAdapter);

    }
    //add code here for slicing fruit
    public void sliceFruit()
    {

    }
    //code for when user clicks on settings button
    public void settings(View view)
    {
        // Create an Intent to start the settings activity
        Intent settings = new Intent(this,Settings_Activity.class);
        //Start the settings activity
        startActivity(settings);

    }

}
