package com.example.soff;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Context;
import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.ArrayAdapter;
import android.widget.Spinner;
import android.widget.Toast;

import java.nio.charset.Charset;

public class MainActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        //code for the dropdown menu for cuts
        Spinner cutSpinner = (Spinner) findViewById(R.id.cuts_spinner);
        ArrayAdapter<String> myAdapter = new ArrayAdapter<String>(MainActivity.this,
                android.R.layout.simple_list_item_1,getResources().getStringArray(R.array.cuts));
        myAdapter.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);
        cutSpinner.setAdapter(myAdapter);

    }
    //add code here for slicing fruit
    public void sliceFruit(View view)
    {
        String command = "cut1";
        byte[] bytes = command.toString().getBytes(Charset.defaultCharset());
        ((Startup)this.getApplicationContext()).b.write(bytes);

        Context context = getApplicationContext();
        //CharSequence text = ((Startup)this.getApplicationContext()).b.getGetDeviceName();
        CharSequence text = command;
        int duration = Toast.LENGTH_SHORT;

        Toast toast = Toast.makeText(context, text, duration);
        toast.show();

    }
    //code for when user clicks on settings button
    public void settings(View view)
    {
        // Create an Intent to start the settings activity
        Intent settings = new Intent(this,Settings_Activity.class);
        //Start the settings activity
        startActivity(settings);

    }
    public void TestConnection(View view)
    {
        // Create an Intent to start the settings activity
        //Intent connectivity = new Intent(this,Connectivity_Activity.class);
        //Start the settings activity
        //startActivity(connectivity);
        this.finish();

    }

}
