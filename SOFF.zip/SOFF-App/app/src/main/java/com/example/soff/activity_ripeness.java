package com.example.soff;

import androidx.appcompat.app.AppCompatActivity;
import androidx.localbroadcastmanager.content.LocalBroadcastManager;

import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;
import android.content.IntentFilter;
import android.graphics.Bitmap;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.Spinner;
import android.widget.TextView;
import android.widget.Toast;

import java.nio.charset.Charset;

public class activity_ripeness extends AppCompatActivity {
    TextView results;
    String ripefruit = ""; // fruit chosen in drop down

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_ripeness);

        results = (TextView) findViewById(R.id.results);

        // Get the result with the receiver
        LocalBroadcastManager.getInstance(this).registerReceiver(ripeReceiver, new IntentFilter("incomingResult"));

        //code for the dropdown menu for ripe fruits
        Spinner ripeSpinner = (Spinner) findViewById(R.id.ripe_fruit_spin);
        ArrayAdapter<String> myAdapter = new ArrayAdapter<String>(activity_ripeness.this,
                android.R.layout.simple_list_item_1,getResources().getStringArray(R.array.ripe_fruits));
        myAdapter.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);
        ripeSpinner.setAdapter(myAdapter);

        // Change the fruit name when selected
        ripeSpinner.setOnItemSelectedListener(new AdapterView.OnItemSelectedListener() {
            @Override
            public void onItemSelected(AdapterView<?> adapterView, View view, int i, long id) {
                String selectedText = adapterView.getSelectedItem().toString();
                // Save the selected fruit as the current fruit to check ripeness
                ripefruit = selectedText;
                // Only display the toast when it changes from default
                if(i > 0){
                    Toast.makeText(activity_ripeness.this, selectedText, Toast.LENGTH_SHORT).show();
                }
            }
            @Override
            public void onNothingSelected(AdapterView<?> adapterView) {
                String selectedText = "Avocado";
                Toast.makeText(activity_ripeness.this, selectedText, Toast.LENGTH_SHORT).show();
                ripefruit = selectedText;
            }
        });
    }

    // Get the result of the colorsensor and display it
    BroadcastReceiver ripeReceiver = new BroadcastReceiver() {
        @Override
        public void onReceive(Context context, Intent intent) {
            String encodedmessage = intent.getStringExtra("theMessage");

            // Set text on main screem
            Log.d("Main: ",encodedmessage);

            // Display the result
            results.setText(encodedmessage);
        }
    };
    // Start the colorsensor to find is ripe or not
    public void colorsensor(View view){
        String command = "checkripe";
        byte[] bytes = command.toString().getBytes(Charset.defaultCharset());
        ((Startup)this.getApplicationContext()).b.write(bytes);

        Context context = getApplicationContext();
        //CharSequence text = ((Startup)this.getApplicationContext()).b.getGetDeviceName();
        CharSequence text = "Checking ripeness";
        int duration = Toast.LENGTH_SHORT;

        Toast toast = Toast.makeText(context, text, duration);
        toast.show();
    }
    public void done(View view){
        // Create an Intent to redirect to main
        Intent intent = new Intent(activity_ripeness.this, MainActivity.class);
        startActivity(intent);
    }
}
