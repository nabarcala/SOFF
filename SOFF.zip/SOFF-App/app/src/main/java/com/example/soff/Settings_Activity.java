package com.example.soff;

import androidx.appcompat.app.AppCompatActivity;

import android.bluetooth.BluetoothAdapter;
import android.content.Intent;
import android.os.Bundle;
import android.view.View;

import java.nio.charset.Charset;

public class Settings_Activity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_settings_);
    }

    public void connectivity(View view){
        // Create an Intent to start the connectivity activity
        Intent connectivity = new Intent(this,Connectivity_Activity.class);
        //Start the settings activity
        startActivity(connectivity);
    }
    public void fruit_list(View view)
    {
        // Create an Intent to start the settings activity
        Intent fruits = new Intent(this,Fruit_List.class);
        //Start the settings activity
        startActivity(fruits);
    }
    public void ripeness_list(View view)
    {
        Intent ripe = new Intent(this,Ripe_List.class);
        startActivity(ripe);
    }
    public void checkRipeness(View view){
        // Create an Intent to start the ripeness activity
        Intent intent = new Intent(Settings_Activity.this, activity_ripeness.class);
        //Start the ripeness activity
        startActivity(intent);

//        String command = "checkripe";
//        byte[] bytes = command.toString().getBytes(Charset.defaultCharset());
//        ((Startup)this.getApplicationContext()).b.write(bytes);
//
//        Context context = getApplicationContext();
//        //CharSequence text = ((Startup)this.getApplicationContext()).b.getGetDeviceName();
//        CharSequence text = "Checking ripeness";
//        int duration = Toast.LENGTH_SHORT;
//
//        Toast toast = Toast.makeText(context, text, duration);
//        toast.show();
    }
}
